package com.my.server.core

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jcraft.jsch.JSch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme()
            ) {
                ServerDashboardScreen()
            }
        }
    }
}

data class ServerMetrics(
    val cpuUsagePercent: Float = 0f,
    val ramUsedMb: Int = 0,
    val ramTotalMb: Int = 1,
    val diskUsedGb: Float = 0f,
    val diskTotalGb: Float = 1f,
    val isConnected: Boolean = false,
    val errorMessage: String? = null
)

@Composable
fun ServerDashboardScreen() {
    var ip by remember { mutableStateOf("104.128.136.235") }
    var password by remember { mutableStateOf("") }
    var isMonitoring by remember { mutableStateOf(false) }
    var metrics by remember { mutableStateOf(ServerMetrics()) }
    val cpuHistory = remember { mutableStateListOf<Float>() }

    LaunchedEffect(isMonitoring) {
        if (isMonitoring) {
            while (isMonitoring) {
                val result = fetchServerData(ip, "root", password)
                metrics = result
                if (result.isConnected) {
                    cpuHistory.add(result.cpuUsagePercent)
                    if (cpuHistory.size > 20) cpuHistory.removeAt(0)
                } else {
                    isMonitoring = false
                }
                delay(2000)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Server Monitor Core",
            color = Color(0xFF38BDF8),
            fontSize = 24.sp,
            style = MaterialTheme.typography.headlineMedium
        )

        OutlinedTextField(
            value = ip,
            onValueChange = { ip = it },
            label = { Text("IP сервера") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Пароль root") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = { isMonitoring = !isMonitoring },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isMonitoring) Color(0xFFEF4444) else Color(0xFF0284C7)
            )
        ) {
            Text(if (isMonitoring) "Отключиться" else "Подключиться")
        }

        metrics.errorMessage?.let { error ->
            Text(text = error, color = Color(0xFFF87171), fontSize = 14.sp)
        }

        if (metrics.isConnected) {
            // CPU карточка
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Загрузка CPU: ${metrics.cpuUsagePercent.toInt()}%",
                        color = Color.White,
                        fontSize = 18.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    CpuGraph(
                        history = cpuHistory,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                    )
                }
            }

            // RAM карточка
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    val ramPct = if (metrics.ramTotalMb > 0) (metrics.ramUsedMb * 100f / metrics.ramTotalMb) else 0f
                    Text(
                        text = "ОЗУ: ${metrics.ramUsedMb} MB / ${metrics.ramTotalMb} MB (${ramPct.toInt()}%)",
                        color = Color.White,
                        fontSize = 18.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { ramPct / 100f },
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFF38BDF8)
                    )
                }
            }

            // Диск карточка
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    val diskPct = if (metrics.diskTotalGb > 0) (metrics.diskUsedGb * 100f / metrics.diskTotalGb) else 0f
                    Text(
                        text = "Диск: ${"%.1f".format(metrics.diskUsedGb)} GB / ${"%.1f".format(metrics.diskTotalGb)} GB (${diskPct.toInt()}%)",
                        color = Color.White,
                        fontSize = 18.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { diskPct / 100f },
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFF34D399)
                    )
                }
            }
        }
    }
}

@Composable
fun CpuGraph(history: List<Float>, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        if (history.size < 2) return@Canvas
        val stepX = size.width / (history.size - 1)
        val path = Path()

        history.forEachIndexed { index, value ->
            val x = index * stepX
            val y = size.height - (value / 100f * size.height)
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }

        drawPath(
            path = path,
            color = Color(0xFF38BDF8),
            style = Stroke(width = 6f)
        )
    }
}

suspend fun fetchServerData(ip: String, user: String, pass: String): ServerMetrics = withContext(Dispatchers.IO) {
    try {
        val jsch = JSch()
        val session = jsch.getSession(user, ip, 22)
        session.setPassword(pass)
        session.setConfig("StrictHostKeyChecking", "no")
        session.timeout = 3000
        session.connect()

        val command = "top -bn1 | grep 'Cpu(s)' && free -m && df -m /"
        val channel = session.openChannel("exec") as com.jcraft.jsch.ChannelExec
        channel.setCommand(command)

        val reader = BufferedReader(InputStreamReader(channel.inputStream))
        channel.connect()

        val lines = reader.readLines()
        session.disconnect()

        var cpuUsage = 0f
        var ramUsed = 0
        var ramTotal = 1
        var diskUsed = 0f
        var diskTotal = 1f

        for (line in lines) {
            when {
                line.contains("Cpu(s)") -> {
                    val idle = line.substringAfter("id,").substringBefore("id").trim().split(" ")[0].replace(",", ".").toFloatOrNull() ?: 100f
                    cpuUsage = 100f - idle
                }
                line.startsWith("Mem:") -> {
                    val parts = line.split("\\s+".toRegex())
                    if (parts.size >= 3) {
                        ramTotal = parts[1].toIntOrNull() ?: 1
                        ramUsed = parts[2].toIntOrNull() ?: 0
                    }
                }
                line.contains("/") && !line.contains("Filesystem") -> {
                    val parts = line.split("\\s+".toRegex())
                    if (parts.size >= 4) {
                        diskTotal = (parts[1].toFloatOrNull() ?: 1024f) / 1024f
                        diskUsed = (parts[2].toFloatOrNull() ?: 0f) / 1024f
                    }
                }
            }
        }

        ServerMetrics(cpuUsage, ramUsed, ramTotal, diskUsed, diskTotal, true)
    } catch (e: Exception) {
        ServerMetrics(0f, 0, 1, 0f, 1f, false, "Ошибка SSH: ${e.localizedMessage}")
    }
}
