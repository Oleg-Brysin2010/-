package com.my.server.core

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jcraft.jsch.JSch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFF4F46E5), // Индиго
                    background = Color(0xFFF8FAFC), // Светло-серый чистый фон
                    surface = Color.White
                )
            ) {
                ServerMonitorApp()
            }
        }
    }
}

data class ServerMetrics(
    val cpuUsagePercent: Float = 0f,
    val ramUsedMb: Int = 0,
    val ramTotalMb: Int = 1,
    val diskUsedGb: Float = 0f,
    val diskTotalGb: Float = 1f,
    val uptime: String = "—",
    val isConnected: Boolean = false,
    val errorMessage: String? = null
)

@Composable
fun ServerMonitorApp() {
    var ip by remember { mutableStateOf("104.128.136.235") }
    var user by remember { mutableStateOf("root") }
    var password by remember { mutableStateOf("") }
    
    var isLoading by remember { mutableStateOf(false) }
    var isConnected by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    
    var metrics by remember { mutableStateOf(ServerMetrics()) }
    val cpuHistory = remember { mutableStateListOf<Float>() }

    // Фоновый процесс мониторинга
    LaunchedEffect(isConnected) {
        if (isConnected) {
            while (isConnected) {
                val result = fetchServerData(ip, user, password)
                if (result.isConnected) {
                    metrics = result
                    cpuHistory.add(result.cpuUsagePercent)
                    if (cpuHistory.size > 25) cpuHistory.removeAt(0)
                } else {
                    errorMessage = result.errorMessage
                    isConnected = false
                }
                delay(2000)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF1F5F9))
    ) {
        AnimatedVisibility(
            visible = !isConnected,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            LoginScreen(
                ip = ip,
                onIpChange = { ip = it },
                user = user,
                onUserChange = { user = it },
                password = password,
                onPasswordChange = { password = it },
                isLoading = isLoading,
                errorMessage = errorMessage,
                onConnectClick = {
                    isLoading = true
                    errorMessage = null
                    // Пробное подключение
                    kotlinx.coroutines.GlobalScope.run {
                        // Вход выполняется асинхронно
                    }
                    isConnected = true
                    isLoading = false
                }
            )
        }

        AnimatedVisibility(
            visible = isConnected,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            DashboardScreen(
                ip = ip,
                metrics = metrics,
                cpuHistory = cpuHistory,
                onDisconnect = {
                    isConnected = false
                    cpuHistory.clear()
                    metrics = ServerMetrics()
                }
            )
        }
    }
}

// ==========================================
// 1. ЭКРАН ВХОДА (LOGIN SCREEN)
// ==========================================
@Composable
fun LoginScreen(
    ip: String, onIpChange: (String) -> Unit,
    user: String, onUserChange: (String) -> Unit,
    password: String, onPasswordChange: (String) -> Unit,
    isLoading: Boolean,
    errorMessage: String?,
    onConnectClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(modifier = Modifier.height(40.dp))

        // Иконка / Логотип
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(Color(0xFF4F46E5), Color(0xFF06B6D4))
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "SSH",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Server Core Monitor",
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0F172A)
        )
        Text(
            text = "Подключитесь к вашему VPS серверу",
            fontSize = 14.sp,
            color = Color(0xFF64748B)
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Карточка формы
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(12.dp, RoundedCornerShape(24.dp), spotColor = Color(0x1A000000)),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                OutlinedTextField(
                    value = ip,
                    onValueChange = onIpChange,
                    label = { Text("IP-адрес сервера") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = user,
                    onValueChange = onUserChange,
                    label = { Text("Пользователь") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = onPasswordChange,
                    label = { Text("Пароль root") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                errorMessage?.let { error ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFFEE2E2))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = error,
                            color = Color(0xFF991B1B),
                            fontSize = 13.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = onConnectClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    enabled = !isLoading && password.isNotEmpty(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5))
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(24.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text(
                            text = "Подключиться",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// 2. ЭКРАН ДАШБОРДА (DASHBOARD SCREEN)
// ==========================================
@Composable
fun DashboardScreen(
    ip: String,
    metrics: ServerMetrics,
    cpuHistory: List<Float>,
    onDisconnect: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Шапка сервера
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(Color(0xFFE2E8F0), Color(0xFFE2E8F0))))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF10B981))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ОНЛАЙН",
                            color = Color(0xFF10B981),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = ip,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        text = "Uptime: ${metrics.uptime}",
                        fontSize = 12.sp,
                        color = Color(0xFF64748B)
                    )
                }

                OutlinedButton(
                    onClick = onDisconnect,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444))
                ) {
                    Text("Выйти")
                }
            }
        }

        // Карточка CPU с графиком
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Процессор (CPU)",
                            fontSize = 14.sp,
                            color = Color(0xFF64748B)
                        )
                        Text(
                            text = "${metrics.cpuUsagePercent.toInt()}%",
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                    }
                    StatusBadge(
                        text = if (metrics.cpuUsagePercent > 80) "Высокая" else "Норма",
                        isWarning = metrics.cpuUsagePercent > 80
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                SmoothCpuGraph(
                    history = cpuHistory,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                )
            }
        }

        // Карточка ОЗУ (RAM)
        val ramPct = if (metrics.ramTotalMb > 0) (metrics.ramUsedMb * 100f / metrics.ramTotalMb) else 0f
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Оперативная память",
                            fontSize = 14.sp,
                            color = Color(0xFF64748B)
                        )
                        Text(
                            text = "${metrics.ramUsedMb} MB / ${metrics.ramTotalMb} MB",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                    }
                    Text(
                        text = "${ramPct.toInt()}%",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF4F46E5)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                LinearProgressIndicator(
                    progress = { ramPct / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(CircleShape),
                    color = Color(0xFF4F46E5),
                    trackColor = Color(0xFFEEF2FF)
                )
            }
        }

        // Карточка Диска (Disk)
        val diskPct = if (metrics.diskTotalGb > 0) (metrics.diskUsedGb * 100f / metrics.diskTotalGb) else 0f
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Накопитель (Диск /)",
                            fontSize = 14.sp,
                            color = Color(0xFF64748B)
                        )
                        Text(
                            text = "${"%.1f".format(metrics.diskUsedGb)} GB / ${"%.1f".format(metrics.diskTotalGb)} GB",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                    }
                    Text(
                        text = "${diskPct.toInt()}%",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF06B6D4)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                LinearProgressIndicator(
                    progress = { diskPct / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(CircleShape),
                    color = Color(0xFF06B6D4),
                    trackColor = Color(0xFFECFEFF)
                )
            }
        }
    }
}

// ==========================================
// 3. КОМПОНЕНТЫ И ГРАФИК
// ==========================================
@Composable
fun StatusBadge(text: String, isWarning: Boolean) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isWarning) Color(0xFFFEE2E2) else Color(0xFFDCFCE7))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            color = if (isWarning) Color(0xFF991B1B) else Color(0xFF166534),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun SmoothCpuGraph(
    history: List<Float>,
    modifier: Modifier = Modifier,
    lineColor: Color = Color(0xFF4F46E5)
) {
    Canvas(modifier = modifier) {
        if (history.size < 2) return@Canvas

        val width = size.width
        val height = size.height
        val stepX = width / (history.size - 1)

        val strokePath = Path()
        val fillPath = Path()

        history.forEachIndexed { index, value ->
            val x = index * stepX
            val clampedValue = value.coerceIn(0f, 100f)
            val y = height - (clampedValue / 100f * (height - 20f)) - 10f

            if (index == 0) {
                strokePath.moveTo(x, y)
                fillPath.moveTo(x, height)
                fillPath.lineTo(x, y)
            } else {
                strokePath.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
        }

        fillPath.lineTo(width, height)
        fillPath.close()

        // Заполнение градиентом
        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(
                    lineColor.copy(alpha = 0.25f),
                    Color.Transparent
                )
            )
        )

        // Рисование линии
        drawPath(
            path = strokePath,
            color = lineColor,
            style = Stroke(width = 6f)
        )

        // Светящаяся точка на последнем значении
        val lastVal = history.last().coerceIn(0f, 100f)
        val lastX = width
        val lastY = height - (lastVal / 100f * (height - 20f)) - 10f

        drawCircle(
            color = lineColor,
            radius = 8f,
            center = androidx.compose.ui.geometry.Offset(lastX, lastY)
        )
        drawCircle(
            color = Color.White,
            radius = 4f,
            center = androidx.compose.ui.geometry.Offset(lastX, lastY)
        )
    }
}

// ==========================================
// 4. ПОЛУЧЕНИЕ ДАННЫХ ПО SSH
// ==========================================
suspend fun fetchServerData(ip: String, user: String, pass: String): ServerMetrics = withContext(Dispatchers.IO) {
    try {
        val jsch = JSch()
        val session = jsch.getSession(user, ip, 22)
        session.setPassword(pass)
        session.setConfig("StrictHostKeyChecking", "no")
        session.timeout = 4000
        session.connect()

        val command = "uptime -p && top -bn1 | grep 'Cpu(s)' && free -m && df -m /"
        val channel = session.openChannel("exec") as com.jcraft.jsch.ChannelExec
        channel.setCommand(command)

        val reader = BufferedReader(InputStreamReader(channel.inputStream))
        channel.connect()

        val lines = reader.readLines()
        session.disconnect()

        var cpuUsage = 0f
        var ramUsed = 0
        var ramTotal = 1
        var diskUsed = 0f
        var diskTotal = 1f
        var uptimeStr = "—"

        for (line in lines) {
            when {
                line.startsWith("up ") -> {
                    uptimeStr = line.replace("up ", "")
                }
                line.contains("Cpu(s)") -> {
                    val idle = line.substringAfter("id,").substringBefore("id").trim().split(" ")[0].replace(",", ".").toFloatOrNull() ?: 100f
                    cpuUsage = 100f - idle
                }
                line.startsWith("Mem:") -> {
                    val parts = line.split("\\s+".toRegex())
                    if (parts.size >= 3) {
                        ramTotal = parts[1].toIntOrNull() ?: 1
                        ramUsed = parts[2].toIntOrNull() ?: 0
                    }
                }
                line.contains("/") && !line.contains("Filesystem") -> {
                    val parts = line.split("\\s+".toRegex())
                    if (parts.size >= 4) {
                        diskTotal = (parts[1].toFloatOrNull() ?: 1024f) / 1024f
                        diskUsed = (parts[2].toFloatOrNull() ?: 0f) / 1024f
                    }
                }
            }
        }

        ServerMetrics(cpuUsage, ramUsed, ramTotal, diskUsed, diskTotal, uptimeStr, true)
    } catch (e: Exception) {
        ServerMetrics(0f, 0, 1, 0f, 1f, "—", false, "Ошибка SSH: ${e.localizedMessage}")
    }
}

